/*******************************************************************************
* Filename      : spi2registers.hpp
*
* Details       : Serial peripheral interface/Inter-IC sound. This header file
*                 is auto-generated for STM32L4x1 device.
*
*
*******************************************************************************/

#if !defined(SPI2REGISTERS_HPP)
#define SPI2REGISTERS_HPP

#include "spi2fieldvalues.hpp"  //for Bits Fields defs 
#include "registerbase.hpp"   //for RegisterBase
#include "register.hpp"       //for Register
#include "accessmode.hpp"     //for ReadMode, WriteMode, ReadWriteMode  

struct SPI2
{
  struct SPI2CR1Base {} ;

  struct CR1 : public RegisterBase<0x40003800, 32, ReadWriteMode>
  {
    using BIDIMODE = SPI2_CR1_BIDIMODE_Values<SPI2::CR1, 15, 1, ReadWriteMode, SPI2CR1Base> ;
    using BIDIOE = SPI2_CR1_BIDIOE_Values<SPI2::CR1, 14, 1, ReadWriteMode, SPI2CR1Base> ;
    using CRCEN = SPI2_CR1_CRCEN_Values<SPI2::CR1, 13, 1, ReadWriteMode, SPI2CR1Base> ;
    using CRCNEXT = SPI2_CR1_CRCNEXT_Values<SPI2::CR1, 12, 1, ReadWriteMode, SPI2CR1Base> ;
    using DFF = SPI2_CR1_DFF_Values<SPI2::CR1, 11, 1, ReadWriteMode, SPI2CR1Base> ;
    using RXONLY = SPI2_CR1_RXONLY_Values<SPI2::CR1, 10, 1, ReadWriteMode, SPI2CR1Base> ;
    using SSM = SPI2_CR1_SSM_Values<SPI2::CR1, 9, 1, ReadWriteMode, SPI2CR1Base> ;
    using SSI = SPI2_CR1_SSI_Values<SPI2::CR1, 8, 1, ReadWriteMode, SPI2CR1Base> ;
    using LSBFIRST = SPI2_CR1_LSBFIRST_Values<SPI2::CR1, 7, 1, ReadWriteMode, SPI2CR1Base> ;
    using SPE = SPI2_CR1_SPE_Values<SPI2::CR1, 6, 1, ReadWriteMode, SPI2CR1Base> ;
    using BR = SPI2_CR1_BR_Values<SPI2::CR1, 3, 3, ReadWriteMode, SPI2CR1Base> ;
    using MSTR = SPI2_CR1_MSTR_Values<SPI2::CR1, 2, 1, ReadWriteMode, SPI2CR1Base> ;
    using CPOL = SPI2_CR1_CPOL_Values<SPI2::CR1, 1, 1, ReadWriteMode, SPI2CR1Base> ;
    using CPHA = SPI2_CR1_CPHA_Values<SPI2::CR1, 0, 1, ReadWriteMode, SPI2CR1Base> ;
    using FieldValues = SPI2_CR1_CPHA_Values<SPI2::CR1, 0, 0, NoAccess, NoAccess> ;
  } ;

  template<typename... T> 
  using CR1Pack  = Register<0x40003800, 32, ReadWriteMode, SPI2CR1Base, T...> ;

  struct SPI2CR2Base {} ;

  struct CR2 : public RegisterBase<0x40003804, 32, ReadWriteMode>
  {
    using RXDMAEN = SPI2_CR2_RXDMAEN_Values<SPI2::CR2, 0, 1, ReadWriteMode, SPI2CR2Base> ;
    using TXDMAEN = SPI2_CR2_TXDMAEN_Values<SPI2::CR2, 1, 1, ReadWriteMode, SPI2CR2Base> ;
    using SSOE = SPI2_CR2_SSOE_Values<SPI2::CR2, 2, 1, ReadWriteMode, SPI2CR2Base> ;
    using NSSP = SPI2_CR2_NSSP_Values<SPI2::CR2, 3, 1, ReadWriteMode, SPI2CR2Base> ;
    using FRF = SPI2_CR2_FRF_Values<SPI2::CR2, 4, 1, ReadWriteMode, SPI2CR2Base> ;
    using ERRIE = SPI2_CR2_ERRIE_Values<SPI2::CR2, 5, 1, ReadWriteMode, SPI2CR2Base> ;
    using RXNEIE = SPI2_CR2_RXNEIE_Values<SPI2::CR2, 6, 1, ReadWriteMode, SPI2CR2Base> ;
    using TXEIE = SPI2_CR2_TXEIE_Values<SPI2::CR2, 7, 1, ReadWriteMode, SPI2CR2Base> ;
    using DS = SPI2_CR2_DS_Values<SPI2::CR2, 8, 4, ReadWriteMode, SPI2CR2Base> ;
    using FRXTH = SPI2_CR2_FRXTH_Values<SPI2::CR2, 12, 1, ReadWriteMode, SPI2CR2Base> ;
    using LDMA_RX = SPI2_CR2_LDMA_RX_Values<SPI2::CR2, 13, 1, ReadWriteMode, SPI2CR2Base> ;
    using LDMA_TX = SPI2_CR2_LDMA_TX_Values<SPI2::CR2, 14, 1, ReadWriteMode, SPI2CR2Base> ;
    using FieldValues = SPI2_CR2_LDMA_TX_Values<SPI2::CR2, 0, 0, NoAccess, NoAccess> ;
  } ;

  template<typename... T> 
  using CR2Pack  = Register<0x40003804, 32, ReadWriteMode, SPI2CR2Base, T...> ;

  struct SPI2SRBase {} ;

  struct SR : public RegisterBase<0x40003808, 32, ReadWriteMode>
  {
    using RXNE = SPI2_SR_RXNE_Values<SPI2::SR, 0, 1, ReadMode, SPI2SRBase> ;
    using TXE = SPI2_SR_TXE_Values<SPI2::SR, 1, 1, ReadMode, SPI2SRBase> ;
    using CRCERR = SPI2_SR_CRCERR_Values<SPI2::SR, 4, 1, ReadWriteMode, SPI2SRBase> ;
    using MODF = SPI2_SR_MODF_Values<SPI2::SR, 5, 1, ReadMode, SPI2SRBase> ;
    using OVR = SPI2_SR_OVR_Values<SPI2::SR, 6, 1, ReadMode, SPI2SRBase> ;
    using BSY = SPI2_SR_BSY_Values<SPI2::SR, 7, 1, ReadMode, SPI2SRBase> ;
    using TIFRFE = SPI2_SR_TIFRFE_Values<SPI2::SR, 8, 1, ReadMode, SPI2SRBase> ;
    using FRLVL = SPI2_SR_FRLVL_Values<SPI2::SR, 9, 2, ReadMode, SPI2SRBase> ;
    using FTLVL = SPI2_SR_FTLVL_Values<SPI2::SR, 11, 2, ReadMode, SPI2SRBase> ;
    using FieldValues = SPI2_SR_FTLVL_Values<SPI2::SR, 0, 0, NoAccess, NoAccess> ;
  } ;

  template<typename... T> 
  using SRPack  = Register<0x40003808, 32, ReadWriteMode, SPI2SRBase, T...> ;

  struct SPI2DRBase {} ;

  struct DR : public RegisterBase<0x4000380C, 32, ReadWriteMode>
  {
    using DRField = SPI2_DR_DR_Values<SPI2::DR, 0, 16, ReadWriteMode, SPI2DRBase> ;
    using FieldValues = SPI2_DR_DR_Values<SPI2::DR, 0, 0, NoAccess, NoAccess> ;
  } ;

  template<typename... T> 
  using DRPack  = Register<0x4000380C, 32, ReadWriteMode, SPI2DRBase, T...> ;

  struct SPI2CRCPRBase {} ;

  struct CRCPR : public RegisterBase<0x40003810, 32, ReadWriteMode>
  {
    using CRCPOLY = SPI2_CRCPR_CRCPOLY_Values<SPI2::CRCPR, 0, 16, ReadWriteMode, SPI2CRCPRBase> ;
    using FieldValues = SPI2_CRCPR_CRCPOLY_Values<SPI2::CRCPR, 0, 0, NoAccess, NoAccess> ;
  } ;

  template<typename... T> 
  using CRCPRPack  = Register<0x40003810, 32, ReadWriteMode, SPI2CRCPRBase, T...> ;

  struct SPI2RXCRCRBase {} ;

  struct RXCRCR : public RegisterBase<0x40003814, 32, ReadMode>
  {
    using RxCRC = SPI2_RXCRCR_RxCRC_Values<SPI2::RXCRCR, 0, 16, ReadMode, SPI2RXCRCRBase> ;
    using FieldValues = SPI2_RXCRCR_RxCRC_Values<SPI2::RXCRCR, 0, 0, NoAccess, NoAccess> ;
  } ;

  template<typename... T> 
  using RXCRCRPack  = Register<0x40003814, 32, ReadMode, SPI2RXCRCRBase, T...> ;

  struct SPI2TXCRCRBase {} ;

  struct TXCRCR : public RegisterBase<0x40003818, 32, ReadMode>
  {
    using TxCRC = SPI2_TXCRCR_TxCRC_Values<SPI2::TXCRCR, 0, 16, ReadMode, SPI2TXCRCRBase> ;
    using FieldValues = SPI2_TXCRCR_TxCRC_Values<SPI2::TXCRCR, 0, 0, NoAccess, NoAccess> ;
  } ;

  template<typename... T> 
  using TXCRCRPack  = Register<0x40003818, 32, ReadMode, SPI2TXCRCRBase, T...> ;

} ;

#endif //#if !defined(SPI2REGISTERS_HPP)
