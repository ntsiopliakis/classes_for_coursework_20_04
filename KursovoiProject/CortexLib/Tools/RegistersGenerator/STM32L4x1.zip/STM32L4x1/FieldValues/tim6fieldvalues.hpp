/*******************************************************************************
* Filename      : tim6fieldvalues.hpp
*
* Details       : Enumerations related with TIM6 peripheral. This header file is
*                 auto-generated for STM32L4x1 device.
*
*
*******************************************************************************/

#if !defined(TIM6ENUMS_HPP)
#define TIM6ENUMS_HPP

#include "fieldvalue.hpp"     //for FieldValues 

template <typename Reg, size_t offset, size_t size, typename AccessMode, typename BaseType> 
struct TIM6_CR1_ARPE_Values: public RegisterField<Reg, offset, size, AccessMode> 
{
  using Value0 = FieldValue<TIM6_CR1_ARPE_Values, BaseType, 0U> ;
  using Value1 = FieldValue<TIM6_CR1_ARPE_Values, BaseType, 1U> ;
} ;

template <typename Reg, size_t offset, size_t size, typename AccessMode, typename BaseType> 
struct TIM6_CR1_OPM_Values: public RegisterField<Reg, offset, size, AccessMode> 
{
  using Value0 = FieldValue<TIM6_CR1_OPM_Values, BaseType, 0U> ;
  using Value1 = FieldValue<TIM6_CR1_OPM_Values, BaseType, 1U> ;
} ;

template <typename Reg, size_t offset, size_t size, typename AccessMode, typename BaseType> 
struct TIM6_CR1_URS_Values: public RegisterField<Reg, offset, size, AccessMode> 
{
  using Value0 = FieldValue<TIM6_CR1_URS_Values, BaseType, 0U> ;
  using Value1 = FieldValue<TIM6_CR1_URS_Values, BaseType, 1U> ;
} ;

template <typename Reg, size_t offset, size_t size, typename AccessMode, typename BaseType> 
struct TIM6_CR1_UDIS_Values: public RegisterField<Reg, offset, size, AccessMode> 
{
  using Value0 = FieldValue<TIM6_CR1_UDIS_Values, BaseType, 0U> ;
  using Value1 = FieldValue<TIM6_CR1_UDIS_Values, BaseType, 1U> ;
} ;

template <typename Reg, size_t offset, size_t size, typename AccessMode, typename BaseType> 
struct TIM6_CR1_CEN_Values: public RegisterField<Reg, offset, size, AccessMode> 
{
  using Value0 = FieldValue<TIM6_CR1_CEN_Values, BaseType, 0U> ;
  using Value1 = FieldValue<TIM6_CR1_CEN_Values, BaseType, 1U> ;
} ;

template <typename Reg, size_t offset, size_t size, typename AccessMode, typename BaseType> 
struct TIM6_CR2_MMS_Values: public RegisterField<Reg, offset, size, AccessMode> 
{
  using Value0 = FieldValue<TIM6_CR2_MMS_Values, BaseType, 0U> ;
  using Value1 = FieldValue<TIM6_CR2_MMS_Values, BaseType, 1U> ;
  using Value2 = FieldValue<TIM6_CR2_MMS_Values, BaseType, 2U> ;
  using Value3 = FieldValue<TIM6_CR2_MMS_Values, BaseType, 3U> ;
  using Value4 = FieldValue<TIM6_CR2_MMS_Values, BaseType, 4U> ;
  using Value5 = FieldValue<TIM6_CR2_MMS_Values, BaseType, 5U> ;
  using Value6 = FieldValue<TIM6_CR2_MMS_Values, BaseType, 6U> ;
  using Value7 = FieldValue<TIM6_CR2_MMS_Values, BaseType, 7U> ;
} ;

template <typename Reg, size_t offset, size_t size, typename AccessMode, typename BaseType> 
struct TIM6_DIER_UDE_Values: public RegisterField<Reg, offset, size, AccessMode> 
{
  using Value0 = FieldValue<TIM6_DIER_UDE_Values, BaseType, 0U> ;
  using Value1 = FieldValue<TIM6_DIER_UDE_Values, BaseType, 1U> ;
} ;

template <typename Reg, size_t offset, size_t size, typename AccessMode, typename BaseType> 
struct TIM6_DIER_UIE_Values: public RegisterField<Reg, offset, size, AccessMode> 
{
  using Value0 = FieldValue<TIM6_DIER_UIE_Values, BaseType, 0U> ;
  using Value1 = FieldValue<TIM6_DIER_UIE_Values, BaseType, 1U> ;
} ;

template <typename Reg, size_t offset, size_t size, typename AccessMode, typename BaseType> 
struct TIM6_SR_UIF_Values: public RegisterField<Reg, offset, size, AccessMode> 
{
  using Value0 = FieldValue<TIM6_SR_UIF_Values, BaseType, 0U> ;
  using Value1 = FieldValue<TIM6_SR_UIF_Values, BaseType, 1U> ;
} ;

template <typename Reg, size_t offset, size_t size, typename AccessMode, typename BaseType> 
struct TIM6_EGR_UG_Values: public RegisterField<Reg, offset, size, AccessMode> 
{
  using Value0 = FieldValue<TIM6_EGR_UG_Values, BaseType, 0U> ;
  using Value1 = FieldValue<TIM6_EGR_UG_Values, BaseType, 1U> ;
} ;

template <typename Reg, size_t offset, size_t size, typename AccessMode, typename BaseType> 
struct TIM6_CNT_CNT_Values: public RegisterField<Reg, offset, size, AccessMode> 
{
} ;

template <typename Reg, size_t offset, size_t size, typename AccessMode, typename BaseType> 
struct TIM6_PSC_PSC_Values: public RegisterField<Reg, offset, size, AccessMode> 
{
} ;

template <typename Reg, size_t offset, size_t size, typename AccessMode, typename BaseType> 
struct TIM6_ARR_ARR_Values: public RegisterField<Reg, offset, size, AccessMode> 
{
} ;

#endif //#if !defined(TIM6ENUMS_HPP)
